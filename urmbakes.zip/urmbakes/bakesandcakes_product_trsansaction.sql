-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: recess.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: bakesandcakes
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `product_trsansaction`
--

DROP TABLE IF EXISTS `product_trsansaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_trsansaction` (
  `product_transaction_id` int NOT NULL AUTO_INCREMENT,
  `retailer_id` int NOT NULL,
  `transaction_type` int NOT NULL COMMENT '1 -> to retailer, 2-> To Inventoty, 3-> Rerturn From Retailer',
  `sales_order_id` int NOT NULL,
  `salesman_id` int NOT NULL,
  `inventory_id` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_transaction_id`),
  KEY `product_trsansaction_fk0` (`retailer_id`),
  KEY `product_trsansaction_fk1` (`inventory_id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_trsansaction`
--

LOCK TABLES `product_trsansaction` WRITE;
/*!40000 ALTER TABLE `product_trsansaction` DISABLE KEYS */;
INSERT INTO `product_trsansaction` VALUES (1,0,2,0,0,1,1,'2022-01-05 13:44:58'),(7,1,1,1,2,1,2,'2022-01-05 14:14:18'),(9,0,2,0,0,1,1,'2022-01-12 10:58:48'),(10,0,2,0,0,1,1,'2022-01-12 11:01:15'),(14,1,1,2,2,1,2,'2022-01-12 11:33:43'),(15,0,2,0,0,1,1,'2022-01-21 11:04:23'),(16,0,2,0,0,1,1,'2022-01-21 11:04:31'),(17,34,1,14,2,1,2,'2022-01-22 04:24:24'),(18,34,1,13,2,1,2,'2022-01-22 04:25:17'),(19,34,1,16,2,1,2,'2022-01-22 04:35:32'),(20,1,1,17,2,1,2,'2022-01-22 06:28:07'),(21,35,1,20,2,1,2,'2022-01-27 09:42:45'),(22,39,1,22,2,1,2,'2022-01-29 15:41:33'),(23,40,1,23,2,1,2,'2022-02-02 09:43:44'),(24,40,1,25,2,1,2,'2022-02-02 10:09:19'),(25,1,1,29,2,1,2,'2022-02-03 13:47:45'),(26,1,1,30,2,1,2,'2022-02-03 13:50:09'),(31,1,1,38,2,1,2,'2022-02-11 08:34:58'),(30,1,1,32,2,1,2,'2022-02-09 10:27:17'),(32,1,1,39,2,1,2,'2022-02-11 08:37:46'),(33,1,1,41,2,1,2,'2022-02-11 09:03:25'),(34,1,1,41,2,1,2,'2022-02-11 09:04:15'),(35,1,1,41,2,1,2,'2022-02-11 09:04:57'),(36,1,1,41,2,1,2,'2022-02-11 09:05:56'),(37,1,1,41,2,1,2,'2022-02-11 09:06:45'),(38,1,1,41,2,1,2,'2022-02-11 09:08:27'),(39,1,1,41,2,1,2,'2022-02-11 09:08:55'),(40,1,1,41,2,1,2,'2022-02-11 09:12:46'),(41,1,1,41,2,1,2,'2022-02-11 09:13:52'),(42,1,1,42,2,1,2,'2022-02-11 09:16:01'),(43,1,1,42,2,1,2,'2022-02-11 09:18:00'),(44,1,1,12,2,1,2,'2022-02-11 13:46:58'),(45,1,1,11,2,1,2,'2022-02-11 13:47:41'),(46,1,1,26,2,1,2,'2022-02-11 13:52:55'),(47,1,1,26,2,1,2,'2022-02-11 13:53:33'),(48,1,1,21,2,1,2,'2022-02-11 14:07:34'),(49,1,1,47,2,1,2,'2022-02-12 11:27:03'),(50,41,1,49,2,1,2,'2022-02-14 03:20:24'),(51,41,1,49,2,1,2,'2022-02-14 03:20:55'),(52,40,1,24,2,1,2,'2022-02-14 12:26:29'),(53,1,1,54,2,1,2,'2022-02-14 13:59:48'),(54,1,1,54,2,1,2,'2022-02-14 14:00:08'),(55,38,1,55,2,1,2,'2022-02-14 14:02:58'),(56,41,1,56,2,1,2,'2022-02-14 15:12:52'),(57,41,1,56,2,1,2,'2022-02-14 15:13:20'),(58,41,1,56,2,1,2,'2022-02-14 15:13:41'),(59,39,1,58,2,1,2,'2022-02-15 04:38:51'),(60,39,1,58,2,1,2,'2022-02-15 04:39:45'),(61,40,1,60,2,1,2,'2022-02-15 10:33:55'),(62,1,1,62,2,1,2,'2022-02-15 12:42:17'),(63,40,1,61,2,1,2,'2022-02-15 13:15:19'),(64,1,1,63,2,1,2,'2022-02-16 05:36:47');
/*!40000 ALTER TABLE `product_trsansaction` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 15:01:56
