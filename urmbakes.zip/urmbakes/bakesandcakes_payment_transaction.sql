-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: recess.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: bakesandcakes
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `payment_transaction`
--

DROP TABLE IF EXISTS `payment_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_transaction` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `payment_type` int NOT NULL COMMENT ' 1 - > Ordered, 2-> Return, 3 -> Cash Collected',
  `payment_amount` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `retailer_id` int NOT NULL,
  `salesman_id` int NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `payment_transaction_fk0` (`sales_order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transaction`
--

LOCK TABLES `payment_transaction` WRITE;
/*!40000 ALTER TABLE `payment_transaction` DISABLE KEYS */;
INSERT INTO `payment_transaction` VALUES (1,1,1,'550','online',1,2,'',2,'0000-00-00 00:00:00'),(2,2,2,'850','online',1,2,'',2,'0000-00-00 00:00:00'),(4,34,1,'1360','online',1,2,'',2,'2022-02-09 16:36:35'),(5,35,2,'340','online',1,2,'',2,'2022-02-09 17:13:07'),(7,0,1,'100','online',1,2,'',2,'2022-02-09 13:10:28'),(8,36,1,'560.0','online',1,2,'',2,'2022-02-10 18:27:07'),(9,37,1,'170.0','online',1,2,'',2,'2022-02-11 08:27:34'),(10,38,1,'360.0','online',1,2,'',2,'2022-02-11 08:34:58'),(11,39,1,'550.0','online',1,2,'',2,'2022-02-11 08:37:45'),(12,40,1,'1700.0','online',1,2,'',2,'2022-02-11 08:39:24'),(13,41,1,'1190.0','online',1,2,'',2,'2022-02-11 09:03:11'),(14,42,1,'2550.0','online',1,2,'',2,'2022-02-11 09:15:51'),(15,43,1,'170.0','online',1,2,'',2,'2022-02-12 06:14:10'),(16,44,1,'850.0','online',1,2,'',2,'2022-02-12 08:40:16'),(17,45,2,'340.0','online',1,2,'',2,'2022-02-12 08:54:59'),(18,46,2,'1700.0','online',1,2,'',2,'2022-02-12 10:52:42'),(19,47,1,'19890.0','online',1,2,'',2,'2022-02-12 11:27:02'),(20,48,2,'28900.0','online',1,2,'',2,'2022-02-12 11:28:11'),(21,49,1,'850.0','online',41,2,'',2,'2022-02-14 03:20:15'),(22,50,2,'300.0','online',41,2,'',2,'2022-02-14 03:21:50'),(23,51,2,'180.0','online',40,2,'',2,'2022-02-14 10:10:27'),(24,52,2,'360.0','online',40,2,'',2,'2022-02-14 10:13:38'),(25,53,2,'2600.0','online',37,2,'',2,'2022-02-14 10:48:17'),(26,54,1,'2550.0','online',1,2,'',2,'2022-02-14 13:59:03'),(27,55,1,'3400.0','online',38,2,'',2,'2022-02-14 14:02:57'),(28,0,3,'100','Cheque Payment',38,2,'',2,'2022-02-14 15:05:17'),(29,0,3,'500','Cash Payment',38,2,'',2,'2022-02-14 15:05:47'),(30,0,3,'588','Online',38,2,'',2,'2022-02-14 15:08:19'),(31,0,3,'200','Cash',38,2,'',2,'2022-02-14 15:08:54'),(32,0,3,'2500','Online',38,2,'',2,'2022-02-14 15:09:14'),(33,56,1,'3400.0','online',41,2,'',2,'2022-02-14 15:12:38'),(34,57,2,'280.0','online',41,2,'',2,'2022-02-14 15:14:24'),(35,0,3,'2000','Cash',41,2,'',2,'2022-02-14 15:15:01'),(36,58,1,'4250.0','online',39,2,'',2,'2022-02-15 04:38:16'),(37,59,2,'600.0','online',39,2,'',2,'2022-02-15 04:40:13'),(38,0,3,'500','Cheque',39,2,'',2,'2022-02-15 04:41:55'),(39,0,3,'3000','Cash',39,2,'',2,'2022-02-15 04:43:15'),(40,60,1,'2550.0','online',40,2,'',2,'2022-02-15 10:33:54'),(41,61,1,'300.0','online',40,2,'',2,'2022-02-15 10:34:13'),(42,62,1,'1700.0','online',1,2,'',2,'2022-02-15 12:42:16'),(43,0,3,'100','Cash',1,2,'',2,'2022-02-16 04:54:31'),(44,0,3,'1000','Cheque',1,2,'',2,'2022-02-16 05:01:22'),(45,0,3,'20','Cheque',1,2,'',2,'2022-02-16 05:19:13'),(46,0,3,'20','Cash',1,2,'',2,'2022-02-16 05:23:15'),(47,0,3,'80','Online',1,2,'',2,'2022-02-16 05:24:55'),(48,0,3,'20','Cash',1,2,'',2,'2022-02-16 05:36:28'),(49,63,1,'60.0','online',1,2,'',2,'2022-02-16 05:36:46');
/*!40000 ALTER TABLE `payment_transaction` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 14:56:07
