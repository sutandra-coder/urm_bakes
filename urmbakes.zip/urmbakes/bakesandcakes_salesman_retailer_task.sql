-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: recess.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: bakesandcakes
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `salesman_retailer_task`
--

DROP TABLE IF EXISTS `salesman_retailer_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salesman_retailer_task` (
  `salesman_retailer_task_id` int NOT NULL AUTO_INCREMENT,
  `retailer_task_type_id` int NOT NULL,
  `is_complete` int NOT NULL,
  `salesman_id` int NOT NULL,
  `retailer_id` int NOT NULL,
  `touchbase_id` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`salesman_retailer_task_id`),
  KEY `salesman_retailer_task_fk0` (`retailer_task_type_id`),
  KEY `salesman_retailer_task_fk1` (`salesman_id`),
  KEY `salesman_retailer_task_fk2` (`retailer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesman_retailer_task`
--

LOCK TABLES `salesman_retailer_task` WRITE;
/*!40000 ALTER TABLE `salesman_retailer_task` DISABLE KEYS */;
INSERT INTO `salesman_retailer_task` VALUES (10,3,1,2,34,60,2,'2022-01-22 04:21:41'),(9,2,0,2,34,60,2,'2022-01-22 04:21:40'),(8,1,0,2,34,60,2,'2022-01-22 04:21:39'),(11,1,1,2,34,62,2,'2022-01-22 04:36:25'),(12,2,1,2,34,62,2,'2022-01-22 04:36:25'),(13,3,1,2,34,62,2,'2022-01-22 04:36:25'),(14,1,1,2,34,63,2,'2022-01-22 04:41:07'),(15,2,1,2,34,63,2,'2022-01-22 04:41:07'),(16,3,1,2,34,63,2,'2022-01-22 04:41:07'),(17,1,0,2,35,65,2,'2022-01-27 09:43:11'),(18,2,1,2,35,65,2,'2022-01-27 09:43:11'),(19,3,1,2,35,65,2,'2022-01-27 09:43:11'),(20,1,1,2,35,66,2,'2022-01-27 09:46:57'),(21,2,1,2,35,66,2,'2022-01-27 09:46:57'),(22,3,1,2,35,66,2,'2022-01-27 09:46:57'),(23,1,0,2,1,68,2,'2022-01-27 10:56:30'),(24,2,1,2,1,68,2,'2022-01-27 10:56:30'),(25,3,1,2,1,68,2,'2022-01-27 10:56:30'),(26,1,1,2,40,81,2,'2022-02-02 09:44:32'),(27,2,1,2,40,81,2,'2022-02-02 09:44:32'),(28,3,1,2,40,81,2,'2022-02-02 09:44:32'),(29,1,0,2,40,83,2,'2022-02-02 10:09:53'),(30,2,0,2,40,83,2,'2022-02-02 10:09:53'),(31,3,0,2,40,83,2,'2022-02-02 10:09:53'),(32,1,1,2,1,85,2,'2022-02-02 15:36:08'),(33,2,1,2,1,85,2,'2022-02-02 15:36:08'),(34,3,1,2,1,85,2,'2022-02-02 15:36:08'),(35,1,1,2,1,87,2,'2022-02-03 00:27:17'),(36,2,1,2,1,87,2,'2022-02-03 00:27:17'),(37,3,1,2,1,87,2,'2022-02-03 00:27:17'),(38,1,0,2,1,96,2,'2022-02-16 06:27:38'),(39,2,0,2,1,96,2,'2022-02-16 06:27:38'),(40,3,0,2,1,96,2,'2022-02-16 06:27:38');
/*!40000 ALTER TABLE `salesman_retailer_task` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 14:58:32
