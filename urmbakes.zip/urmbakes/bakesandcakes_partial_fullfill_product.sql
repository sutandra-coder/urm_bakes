-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: recess.cdcuaa7mp0jm.us-east-2.rds.amazonaws.com    Database: bakesandcakes
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `partial_fullfill_product`
--

DROP TABLE IF EXISTS `partial_fullfill_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partial_fullfill_product` (
  `partial_full_fill_product_id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `retailer_id` int NOT NULL,
  `salesman_id` int NOT NULL,
  `product_id` int NOT NULL,
  `qty` int NOT NULL,
  `last_update_id` int NOT NULL,
  `last_update_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`partial_full_fill_product_id`),
  KEY `partial_fullfill_product_fk0` (`sales_order_id`),
  KEY `partial_fullfill_product_fk1` (`retailer_id`),
  KEY `partial_fullfill_product_fk2` (`salesman_id`),
  KEY `partial_fullfill_product_fk3` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partial_fullfill_product`
--

LOCK TABLES `partial_fullfill_product` WRITE;
/*!40000 ALTER TABLE `partial_fullfill_product` DISABLE KEYS */;
INSERT INTO `partial_fullfill_product` VALUES (1,32,1,2,3,2,1,'2022-02-09 10:29:02'),(2,41,1,2,1,5,2,'2022-02-11 09:13:52'),(3,41,1,2,2,2,2,'2022-02-11 09:13:54'),(4,41,1,2,4,1,2,'2022-02-11 09:13:55'),(5,42,1,2,1,3,2,'2022-02-11 09:18:01'),(6,42,1,2,2,3,2,'2022-02-11 09:18:01'),(7,42,1,2,3,3,2,'2022-02-11 09:18:01'),(8,21,1,2,1,1,2,'2022-02-11 14:07:34'),(9,21,1,2,2,0,2,'2022-02-11 14:07:34'),(10,49,41,2,1,5,2,'2022-02-14 03:20:24'),(11,49,41,2,2,3,2,'2022-02-14 03:20:24'),(12,54,1,2,1,10,2,'2022-02-14 13:59:48'),(13,54,1,2,2,15,2,'2022-02-14 13:59:48'),(14,56,41,2,3,5,2,'2022-02-14 15:12:52'),(15,56,41,2,1,2,2,'2022-02-14 15:12:52'),(16,56,41,2,2,10,2,'2022-02-14 15:12:52'),(17,56,41,2,3,0,2,'2022-02-14 15:13:20'),(18,56,41,2,1,5,2,'2022-02-14 15:13:20'),(19,56,41,2,2,0,2,'2022-02-14 15:13:21'),(20,58,39,2,1,5,2,'2022-02-15 04:38:51'),(21,58,39,2,2,15,2,'2022-02-15 04:38:51'),(22,58,39,2,4,5,2,'2022-02-15 04:38:51');
/*!40000 ALTER TABLE `partial_fullfill_product` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-01 14:59:02
